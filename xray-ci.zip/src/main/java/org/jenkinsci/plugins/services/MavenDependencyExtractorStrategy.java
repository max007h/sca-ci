package org.jenkinsci.plugins.services;

import org.jenkinsci.plugins.services.tools.OSHandler;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.*;

public class MavenDependencyExtractorStrategy implements DependencyExtractor {
    String commandLine = "mvn -o dependency:list | grep \":.*:.*:.*\" | cut -d] -f2- | sed 's/:[a-z]*$//g'";
    public String fullPath;


    public MavenDependencyExtractorStrategy(String commandLine) {
        this.commandLine = commandLine;
    }

    public MavenDependencyExtractorStrategy() {
    }

    @Override
    public List<String> execute() throws IOException, InterruptedException, TimeoutException, ExecutionException {
        return exec_(null);
    }

    @Override
    public List<String> execute(String fullPath) throws IOException, InterruptedException, TimeoutException, ExecutionException {
        return exec_(fullPath);
    }

    private List<String> exec_(String fullPath) throws IOException, InterruptedException, TimeoutException, ExecutionException {
        ProcessBuilder builder = new ProcessBuilder();
        if (OSHandler.isWindows()) {
            builder.command("cmd.exe", "/c", commandLine);
        } else {
            builder.command("sh", "-c", commandLine);
        }
        if(fullPath != null) {
            builder.directory(new File(fullPath).getAbsoluteFile()); // this is where you set the root folder for the executable to run with
        }

        Process process = builder.start();
        return OSHandler.getResultFromChildProcess(process);
    }

}
