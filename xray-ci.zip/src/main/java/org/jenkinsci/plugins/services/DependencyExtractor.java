package org.jenkinsci.plugins.services;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public interface  DependencyExtractor {
    public List<String> execute(String fullPathOfProject) throws IOException, InterruptedException, TimeoutException, ExecutionException;
    public List<String> execute() throws IOException, InterruptedException, TimeoutException, ExecutionException;

}
