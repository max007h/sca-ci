package org.jenkinsci.plugins;

import org.jenkinsci.plugins.services.DependencyExtractor;
import org.jenkinsci.plugins.services.MavenDependencyExtractorStrategy;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public class Main {
    public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException, IOException {

        new MavenDependencyExtractorStrategy("pwd").execute();
        DependencyExtractor mavenDependencyExtractorStrategy = new MavenDependencyExtractorStrategy();
        List<String> result = mavenDependencyExtractorStrategy.execute();

        //result.forEach(e-> System.out.println("===>"+e));
    }


}
